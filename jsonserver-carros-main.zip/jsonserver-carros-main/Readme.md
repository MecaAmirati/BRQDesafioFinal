# Documentação
https://www.npmjs.com/package/json-server 

## Instalação
```bat
npm install -g json-server
```

## Utilização
```bat
json-server --watch db.json -p 3004
```